package com.github.redouanebali.dto.actor;

import java.util.List;
import lombok.Data;

@Data
public class Profiles {

  List<Actor> profiles;
}
